export const createElement = tagName => {
    return document.createElement(tagName);
};
